document.write("<h1>Number Tricks</h1>");
document.write("<ul> <li>I added 9 to " + startingNumber + ". " +
    "The new number is " + newNumber + ". <br> </li>" +
    "<li>I multipled " + newNumber + " by 2. " + "The new number is " + thirdNumber + ".<br> </li>" +

    "<li>I subtracted 4 from " + thirdNumber + ". " + "The new number is " + fourthNumber +". <br> </li>" +

    "<li>I divided " + fourthNumber + " by two. " + " The new number is " + fifthNumber + ". <br></li>" +

    "<li>I subtracted your original number of " + startingNumber + " from " + fifthNumber + ".<br> " + "<br></li></ul>" +

    "<b> Your final number is " + sixthNumber + "! </b> <br><br>");

"<br><br>" ;


alert("Final number is " + sixthNumber + "!");
